<?php
session_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

$host = "localhost";
$dbname = "try2";
$username = "root";
$password = "";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reset_password'])) {
    $email = $_POST['email'];
    $otp = $_POST['otp'];
    $newPassword = $_POST['new_password'];
    $stmt = $pdo->prepare("SELECT * FROM otp_verify WHERE email = :email AND forget_otp = :otp");
    $stmt->bindParam(':email', $email, PDO::PARAM_STR);
    $stmt->bindParam(':otp', $otp, PDO::PARAM_INT);
    $stmt->execute();

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
        $updateStmt = $pdo->prepare("UPDATE otp_verify SET password = :password WHERE email = :email");
        $updateStmt->bindParam(':password', $hashedPassword, PDO::PARAM_STR);
        $updateStmt->bindParam(':email', $email, PDO::PARAM_STR);
        $updateStmt->execute();
        header("Location: login.php");
        exit();
    } else {
        echo "Invalid OTP. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
    <title>Reset Password</title>
    <style>
        body {
            background-image: url(images/1.png);
        }

        .container {
            margin-top: 20px;
        }

        .reset-box {
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            margin: 0 auto;
        }

        .status {
            text-align: center;
        }

        hr {
            border-color: #ddd;
        }

        label {
            display: inline-block;
            width: 30%;
            margin-bottom: 10px;
        }

        input {
            width: 65%;
            padding: 8px;
            margin-bottom: 10px;
        }

        .btn-container {
            text-align: center;
        }

        .btn {
            width: 50%;
            background-color: #28a745;
            color: #fff;
            margin-top: 10px;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="reset-box">
            <div class="status">
                <h3>Reset Password</h3>
            </div>
            <hr>
            <form method="post" action="">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" value="<?php echo isset($_GET['email']) ? $_GET['email'] : ''; ?>" readonly><br>
                <label for="otp">Enter OTP:</label>
                <input type="text" id="otp" name="otp" required><br>
                <label for="new_password">New Password:</label>
                <input type="password" id="new_password" name="new_password" required><br>
                <div class="btn-container">
                    <button type="submit" name="reset_password" class="btn btn-success">Reset Password</button>
                </div>
            </form>
        </div>
    </div>
</body>

</html>
