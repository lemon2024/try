<?php
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}


$user = $_SESSION['user'];


if (isset($_POST['logout'])) {
    session_destroy();
    header("Location: login.php");
    exit();
}
?>
<body>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background: url('images/2.jpg') no-repeat center center fixed;
            -webkit-background-size: cover;
            -moz-background-size: cover;
            -o-background-size: cover;
            background-size: cover;
            font-family: Arial, sans-serif;
        }

        .greeting {
            text-align: center;
            margin-top: 150px;
        }

        .border-box {
            border: 2px solid #fff;
            padding: 20px;
            border-radius: 10px;
            background: rgba(0, 0, 0, 0.5);
            color: #fff;
            display: inline-block;
        }

        .logout-btn {
            display: block;
            margin-top: 20px;
            text-align: center;
        }
    </style>
</head>

    <div class="greeting">
        <div class="border-box">
            <h2>Hello <?php echo $user['name']; ?></h2>
            <form method="post" class="logout-btn">
                <button type="submit" name="logout">Logout</button>
            </form>
        </div>
    </div>
    </body>
</html>
