<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="custom/index.css" rel="stylesheet">
    <title>Register</title>
    <style>
        body {
            background-image: url(images/1.png);
        }

        .container-fluid {
            margin-top: 20px;
        }

        .f1 {
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            margin: 0 auto;
        }

        .status {
            text-align: center;
        }

        hr {
            border-color: #ddd;
        }

        label {
            display: inline-block;
            width: 30%;
            margin-bottom: 10px;
        }

        input {
            width: 65%;
            padding: 8px;
            margin-bottom: 10px;
        }

        .btn {
            width: 100%;
        }
        
        .gender-label {
            display: inline-block;
            margin-right: 10px;
        }

        .error-message {
            color: #ff0000;
            display: none;
            margin-top: 5px;
        }
    </style>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <hr>
                <div class="f1">
                    <form action="process_registration.php" method="POST" id="registrationForm">
                        <label for="name">Full Name:</label>
                        <input type="text" id="name" name="name" placeholder="Full Name" required><br>
                        <label for="email">Email:</label>
                        <input type="email" name="email" id="email" placeholder="juandelacruz@gmail.com" required>
                        <div class="error-message" id="emailErrorMessage">Email is already taken.</div><br>
                        <label for="phone">Phone Number:</label>
                        <input type="tel" id="phone" name="phone" placeholder="Phone Number" required><br>
                        <label>Gender:</label>
                        <label class="gender-label"><input type="radio" name="gender" value="male" required> Male</label>
                        <label class="gender-label"><input type="radio" name="gender" value="female" required> Female</label><br>
                        <label for="password">Password:</label>
                        <input type="password" name="password" required><br>
                        <button type="submit" name="register" class="btn btn-success">Register</button>
                        <button type="button" name="cancel" class="btn btn-danger" onclick="goToLoginPage()">Cancel</button>
                        <script>
                            function goToLoginPage() {
                                window.location.href = 'login.php';
                            }
                            document.getElementById('registrationForm').addEventListener('submit', function (event) {
                                var emailInput = document.getElementById('email');
                                var emailErrorMessage = document.getElementById('emailErrorMessage');                            
                                if (emailAlreadyTaken()) {
                                    event.preventDefault();
                                    emailErrorMessage.style.display = 'block';
                                    emailInput.focus();
                                } else {
                                    emailErrorMessage.style.display = 'none';
                                }
                            });
                            function emailAlreadyTaken() {
                                return emailInput.value.toLowerCase().includes('taken');
                            }
                        </script>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
