<?php
session_start();

$host = "localhost";
$dbname = "try2";
$username = "root";
$password = "";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

if (isset($_POST['otp'])) {
    $otp = $_POST['otp'];
    $email = $_SESSION['email'];

    try {
        $stmt = $pdo->prepare("SELECT * FROM otp_verify WHERE email = :email AND otp = :otp");
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':otp', $otp);
        $stmt->execute();
        $count = $stmt->rowCount();

        if ($count > 0) {
            $insertStmt = $pdo->prepare("INSERT INTO otp_verify (name, email, phone, gender, password, is_verified) SELECT name, email, phone, gender, password, 1 FROM otp_verify WHERE email = :email");
            $insertStmt->bindParam(':email', $email);
            $insertStmt->execute();
            unset($_SESSION['email']);

            echo "OTP verification successful. Account created and activated!";
            header("Location: welcome.php");
            exit();
        } else {
            echo "Invalid OTP. Please try again.";
        }
    } catch (PDOException $e) {
        echo "Database Error: " . $e->getMessage();
    }
}
?>
